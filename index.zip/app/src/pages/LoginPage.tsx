import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Key, 
  User, 
  ArrowRight,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Bot,
  Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { generateVerificationCode, getPlayerById } from '@/data/mockData';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

export function LoginPage() {
  const [userId, setUserId] = useState('');
  const [step, setStep] = useState<'input' | 'verify'>('input');
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState('');
  const [, setPlayer] = useState<ReturnType<typeof getPlayerById>>(undefined);
  const [showBotDialog, setShowBotDialog] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const navigate = useNavigate();

  const handleContinue = () => {
    setError('');
    const id = parseInt(userId);
    
    if (isNaN(id) || id <= 0) {
      setError('Please enter a valid Pekora User ID');
      return;
    }

    const foundPlayer = getPlayerById(id);
    if (!foundPlayer) {
      // Create a mock player for the login demo
      const code = generateVerificationCode();
      setVerificationCode(code);
      setPlayer({
        id,
        username: `User${id}`,
        displayName: `Korone ${code}`,
        level: 1,
        exp: 0,
        maxExp: 100,
        value: 0,
        rap: 0,
        limiteds: 0,
        uniqueItems: 0,
        joinedAt: new Date().toISOString(),
        bio: `Korone ${code}`,
        inventory: [],
        badges: []
      });
    } else {
      const code = generateVerificationCode();
      setVerificationCode(code);
      setPlayer(foundPlayer);
    }
    
    setStep('verify');
  };

  const handleVerify = () => {
    // Simulate bot verification - in real implementation, this would check the player's bio
    setShowBotDialog(true);
  };

  const handleBotVerification = (isBot: boolean) => {
    setShowBotDialog(false);
    if (isBot) {
      setIsVerified(true);
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } else {
      setError('Verification failed. Please make sure your bio contains the verification code.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4">
      <div className="container mx-auto max-w-md">
        {/* Login Card */}
        <div className="bg-card border border-border rounded-lg p-8">
          {step === 'input' ? (
            <>
              <div className="text-center mb-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Key className="h-6 w-6 text-primary" />
                </div>
                <h1 className="text-2xl font-bold">Login to Snolimons</h1>
                <p className="text-muted-foreground mt-1">
                  Enter your Pekora user ID to get started
                </p>
              </div>

              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">
                    Pekora User ID
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="text"
                      placeholder="e.g. 35738"
                      value={userId}
                      onChange={(e) => setUserId(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Find your ID in your Pekora profile URL
                  </p>
                </div>

                <Button 
                  className="w-full"
                  onClick={handleContinue}
                  disabled={!userId}
                >
                  Continue
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </>
          ) : (
            <>
              <div className="text-center mb-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h1 className="text-2xl font-bold">Verify Your Account</h1>
                <p className="text-muted-foreground mt-1">
                  Add this code to your Pekora bio to verify
                </p>
              </div>

              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {isVerified && (
                <Alert className="mb-4 bg-green-500/10 border-green-500/50">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <AlertDescription className="text-green-500">
                    Verification successful! Redirecting...
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-4">
                <div className="bg-muted rounded-lg p-4 text-center">
                  <div className="text-sm text-muted-foreground mb-1">Your verification code</div>
                  <div className="text-3xl font-mono font-bold text-primary tracking-wider">
                    {verificationCode}
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    1. Go to your{' '}
                    <a 
                      href={`https://www.pekora.zip/users/${userId}/profile`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline inline-flex items-center gap-0.5"
                    >
                      Pekora profile
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    2. Add the code <strong className="text-primary">{verificationCode}</strong> to your bio
                  </p>
                  <p className="text-sm text-muted-foreground">
                    3. Click verify below
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    className="flex-1"
                    onClick={() => setStep('input')}
                  >
                    Back
                  </Button>
                  <Button 
                    className="flex-1"
                    onClick={handleVerify}
                  >
                    <Bot className="h-4 w-4 mr-1" />
                    Verify
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Info */}
        <div className="text-center mt-6 text-sm text-muted-foreground">
          <p>Don't have a Pekora account?</p>
          <a 
            href="https://www.pekora.zip"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary hover:underline inline-flex items-center gap-0.5"
          >
            Play Korone
            <ExternalLink className="h-3 w-3" />
          </a>
        </div>
      </div>

      {/* Bot Verification Dialog */}
      <Dialog open={showBotDialog} onOpenChange={setShowBotDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              Bot Verification
            </DialogTitle>
            <DialogDescription>
              Are you a bot or a human? This helps us verify your account.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 mt-4">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => handleBotVerification(false)}
            >
              I'm Human
            </Button>
            <Button 
              className="flex-1"
              onClick={() => handleBotVerification(true)}
            >
              I'm a Bot
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
