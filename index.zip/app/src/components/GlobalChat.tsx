import { useState } from 'react';
import { MessageCircle, ChevronDown, ChevronUp, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { chatMessages } from '@/data/mockData';
import { Link } from 'react-router-dom';

export function GlobalChat() {
  const [isOpen, setIsOpen] = useState(true);
  const [message, setMessage] = useState('');

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-card border border-border rounded-lg shadow-xl z-50 overflow-hidden">
      {/* Header */}
      <div 
        className="flex items-center justify-between px-3 py-2 bg-muted/50 cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2">
          <MessageCircle className="h-4 w-4 text-primary" />
          <span className="font-medium text-sm">Global Chat</span>
          <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded">100</span>
        </div>
        <Button variant="ghost" size="icon" className="h-6 w-6">
          {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
        </Button>
      </div>

      {/* Chat Content */}
      {isOpen && (
        <>
          <div className="h-64 overflow-y-auto p-3 space-y-2">
            {chatMessages.map((msg) => (
              <div key={msg.id} className="text-sm">
                {msg.replyTo && (
                  <span className="text-muted-foreground text-xs">
                    Replying to @{msg.replyTo}:{' '}
                  </span>
                )}
                <Link 
                  to={`/player/${msg.playerId}`}
                  className="font-medium text-primary hover:underline"
                >
                  {msg.playerName}
                </Link>
                <span className="text-muted-foreground text-xs ml-1">{msg.timestamp}</span>
                <p className="text-foreground mt-0.5">{msg.message}</p>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-2 border-t border-border">
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Log in to chat"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="h-8 text-sm"
                disabled
              />
              <Button size="icon" className="h-8 w-8 shrink-0" disabled>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
