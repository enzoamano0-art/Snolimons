import { useParams, Link } from 'react-router-dom';
import { 
  TrendingUp, 
  BarChart3, 
  Users, 
  ExternalLink,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getItemById, formatNumber, players } from '@/data/mockData';

export function ItemPage() {
  const { id } = useParams<{ id: string }>();
  const itemId = parseInt(id || '0');
  const item = getItemById(itemId);

  if (!item) {
    return (
      <div className="container mx-auto max-w-5xl py-12 px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Item not found</h1>
        <p className="text-muted-foreground mb-6">The item you're looking for doesn't exist.</p>
        <Button asChild>
          <Link to="/limiteds">Browse Limiteds</Link>
        </Button>
      </div>
    );
  }

  const valueVsRap = item.rap > 0 ? ((item.value - item.rap) / item.rap * 100) : 0;
  const owners = players.filter(p => p.inventory.some(i => i.itemId === itemId));

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl space-y-6">
        {/* Item Header */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex flex-col md:flex-row items-start gap-6">
            {/* Item Image */}
            <div className="w-32 h-32 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
              {item.image ? (
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-full h-full object-contain"
                />
              ) : (
                <span className="text-4xl text-muted-foreground">?</span>
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-bold">{item.name}</h1>
                {item.rarity && (
                  <Badge 
                    variant="secondary"
                    className={`
                      ${item.rarity === 'mythic' ? 'text-orange-400' :
                        item.rarity === 'legendary' ? 'text-purple-400' :
                        'text-blue-400'}
                    `}
                  >
                    {item.rarity}
                  </Badge>
                )}
              </div>
              <p className="text-muted-foreground">Asset ID: {item.id}</p>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                <div>
                  <div className="text-sm text-muted-foreground flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    Value
                  </div>
                  <div className="text-xl font-bold text-primary">{formatNumber(item.value)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground flex items-center gap-1">
                    <BarChart3 className="h-3 w-3" />
                    RAP
                  </div>
                  <div className="text-xl font-bold">{formatNumber(item.rap)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Demand</div>
                  <div className={`text-xl font-bold capitalize ${
                    item.demand === 'high' ? 'text-green-400' :
                    item.demand === 'normal' ? 'text-yellow-400' :
                    'text-red-400'
                  }`}>
                    {item.demand}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Copies</div>
                  <div className="text-xl font-bold">{item.copies || '?'}</div>
                </div>
              </div>

              {/* Value vs RAP */}
              {item.rap > 0 && (
                <div className="mt-4">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-muted-foreground">Value vs RAP</span>
                    <span className={valueVsRap >= 0 ? 'text-green-400' : 'text-red-400'}>
                      {valueVsRap >= 0 ? '+' : ''}{valueVsRap.toFixed(1)}% {valueVsRap >= 0 ? 'above' : 'below'} RAP
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${valueVsRap >= 0 ? 'bg-green-400' : 'bg-red-400'}`}
                      style={{ width: `${Math.min(Math.abs(valueVsRap), 100)}%` }}
                    />
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2 mt-4">
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Updated {item.updatedAt ? new Date(item.updatedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Unknown'}
                </span>
                <Button variant="outline" size="sm" asChild>
                  <a 
                    href={`https://www.pekora.zip/catalog/${item.id}/${item.name.replace(/\s+/g, '-')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    View on Pekora
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Price History */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <BarChart3 className="h-5 w-5 text-primary" />
            Price History
          </h2>
          <div className="h-48 flex items-end justify-between gap-2">
            {Array.from({ length: 12 }).map((_, i) => (
              <div 
                key={i}
                className="flex-1 bg-primary/20 rounded-t"
                style={{ height: `${30 + Math.random() * 50}%` }}
              />
            ))}
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-2">
            <span>May 5</span>
            <span>Jul 8</span>
            <span>Sep 17</span>
            <span>Jan 31</span>
          </div>
        </div>

        {/* Owners */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <Users className="h-5 w-5 text-primary" />
            Owners
          </h2>
          {owners.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {owners.map(owner => (
                <Link
                  key={owner.id}
                  to={`/player/${owner.id}`}
                  className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg card-hover"
                >
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <span className="font-bold text-muted-foreground">
                      {owner.username.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <div className="font-medium">{owner.displayName}</div>
                    <div className="text-sm text-muted-foreground">@{owner.username}</div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                <span>Scanning player inventories...</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
