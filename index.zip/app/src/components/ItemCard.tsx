import { Link } from 'react-router-dom';
import type { Item } from '@/types';
import { formatNumber } from '@/data/mockData';

interface ItemCardProps {
  item: Item;
  showRarity?: boolean;
}

export function ItemCard({ item, showRarity = true }: ItemCardProps) {
  return (
    <Link 
      to={`/item/${item.id}`}
      className="group block bg-card border border-border rounded-lg p-3 card-hover"
    >
      <div className="flex flex-col items-center">
        {/* Item Image */}
        <div className="w-16 h-16 mb-2 relative">
          {item.image ? (
            <img 
              src={item.image} 
              alt={item.name}
              className="w-full h-full object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"%3E%3Crect width="64" height="64" fill="%23333" rx="8"/%3E%3Ctext x="32" y="36" text-anchor="middle" fill="%23666" font-size="24"%3E?%3C/text%3E%3C/svg%3E';
              }}
            />
          ) : (
            <div className="w-full h-full bg-muted rounded-lg flex items-center justify-center">
              <span className="text-2xl text-muted-foreground">?</span>
            </div>
          )}
        </div>

        {/* Item Name */}
        <h3 className="text-sm font-medium text-center line-clamp-1 mb-1 group-hover:text-primary transition-colors">
          {item.name}
        </h3>

        {/* Value */}
        <div className="text-primary font-bold">
          {formatNumber(item.value)}
        </div>

        {/* RAP */}
        {item.rap > 0 && (
          <div className="text-xs text-muted-foreground">
            RAP: {formatNumber(item.rap)}
          </div>
        )}

        {/* Rarity Badge */}
        {showRarity && item.rarity && (
          <span className={`text-xs mt-1 px-1.5 py-0.5 rounded bg-muted ${
            item.rarity === 'mythic' ? 'text-orange-400' :
            item.rarity === 'legendary' ? 'text-purple-400' :
            'text-blue-400'
          }`}>
            {item.rarity}
          </span>
        )}
      </div>
    </Link>
  );
}
