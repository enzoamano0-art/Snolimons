import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  ChevronDown, 
  Search, 
  MessageCircle,
  Menu,
  X,
  Gift
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { Theme } from '@/types';

interface NavbarProps {
  theme: Theme;
  onThemeChange: (theme: Theme) => void;
}

export function Navbar({ theme, onThemeChange }: NavbarProps) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const isActive = (path: string) => location.pathname === path;

  const navLinks = [
    { label: 'Trading', href: '/trades', hasDropdown: true },
    { label: 'Catalog', href: '/limiteds', hasDropdown: true },
    { label: 'Changes', href: '/value-changes', hasDropdown: true },
    { label: 'Players', href: '/leaderboard', hasDropdown: true },
    { label: 'Misc', href: '#', hasDropdown: true },
  ];

  return (
    <nav className="sticky top-0 z-40 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex h-14 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="relative w-8 h-8 flex items-center justify-center">
              <span className="text-2xl font-bold text-primary">S</span>
            </div>
            <span className="font-bold text-lg hidden sm:block">
              <span className="text-primary">Snoli</span>
              <span className="text-foreground">mons</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <DropdownMenu key={link.label}>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    className={`gap-1 ${isActive(link.href) ? 'text-primary' : ''}`}
                  >
                    {link.label}
                    {link.hasDropdown && <ChevronDown className="h-4 w-4" />}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-48">
                  {link.label === 'Trading' && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link to="/trades">Trade Ads</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/calculator">Trade Calculator</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  {link.label === 'Catalog' && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link to="/limiteds">Limiteds</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/value-changes">Value Changes</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  {link.label === 'Changes' && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link to="/value-changes">Value Changes</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/demand-changes">Demand Changes</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  {link.label === 'Players' && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link to="/leaderboard">Leaderboard</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/players">All Players</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  {link.label === 'Misc' && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link to="/giveaways">Giveaways</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/api">API</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            ))}
            <Button 
              variant="ghost" 
              className={isActive('/giveaways') ? 'text-primary' : ''}
              asChild
            >
              <Link to="/giveaways">
                <Gift className="h-4 w-4 mr-1" />
                Giveaways
              </Link>
            </Button>
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <div className="hidden md:flex items-center relative">
              <Search className="absolute left-2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 w-32 lg:w-48 h-8 text-sm"
              />
            </div>

            {/* Theme Toggle */}
            <div className="hidden sm:flex items-center bg-muted rounded-md p-0.5">
              <Button
                variant="ghost"
                size="sm"
                className={`h-7 px-2 text-xs ${theme === 'kolimons' ? 'bg-card text-primary' : ''}`}
                onClick={() => onThemeChange('kolimons')}
              >
                Snolimons
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className={`h-7 px-2 text-xs ${theme === 'rolimons' ? 'bg-card text-primary' : ''}`}
                onClick={() => onThemeChange('rolimons')}
              >
                Rolimons
              </Button>
            </div>

            {/* Discord */}
            <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
              <a href="https://discord.gg/snolimons" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-4 w-4" />
              </a>
            </Button>

            {/* Login */}
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90 h-8 px-3"
              asChild
            >
              <Link to="/login">Login</Link>
            </Button>

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden h-8 w-8"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  to={link.href}
                  className={`px-4 py-2 rounded-md hover:bg-muted ${isActive(link.href) ? 'text-primary bg-muted' : ''}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                to="/giveaways"
                className={`px-4 py-2 rounded-md hover:bg-muted ${isActive('/giveaways') ? 'text-primary bg-muted' : ''}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Giveaways
              </Link>
              <div className="px-4 py-2">
                <Input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
