import { Link } from 'react-router-dom';
import { 
  TrendingUp, 
  Package, 
  Users, 
  ArrowRight,
  MessageCircle,
  Gamepad2,
  Calculator,
  Gift,
  BarChart3,
  Layers,
  Trophy
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ItemCard } from '@/components/ItemCard';
import { PlayerCard } from '@/components/PlayerCard';
import { items, players, siteStats, formatNumber } from '@/data/mockData';

export function Home() {
  const recentlyUpdated = items.slice(0, 8);
  const topTraders = players.slice(0, 5);

  const exploreLinks = [
    { icon: TrendingUp, label: 'Trade Ads', href: '/trades', color: 'text-blue-400' },
    { icon: BarChart3, label: 'Value Changes', href: '/value-changes', color: 'text-green-400' },
    { icon: Calculator, label: 'Trade Calculator', href: '/calculator', color: 'text-purple-400' },
    { icon: Layers, label: 'Limiteds', href: '/limiteds', color: 'text-orange-400' },
    { icon: Trophy, label: 'Leaderboard', href: '/leaderboard', color: 'text-yellow-400' },
    { icon: Gift, label: 'Giveaways', href: '/giveaways', color: 'text-pink-400' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-hero py-12 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold text-white">
                Snolimons
              </h1>
              <p className="text-white/80 text-lg max-w-xl">
                A community-driven source of reliable values, data, and updates for Korone limited items and helpful trading information
              </p>
              <div className="flex flex-wrap gap-3">
                <Button 
                  className="bg-white/20 hover:bg-white/30 text-white border-0"
                  asChild
                >
                  <a href="https://discord.gg/snolimons" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Discord Server
                  </a>
                </Button>
                <Button 
                  className="bg-white/20 hover:bg-white/30 text-white border-0"
                  asChild
                >
                  <a href="https://www.pekora.zip" target="_blank" rel="noopener noreferrer">
                    <Gamepad2 className="h-4 w-4 mr-2" />
                    Play Korone
                  </a>
                </Button>
              </div>
            </div>
            <div className="flex gap-3">
              <a href="https://discord.gg/snolimons" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center hover:bg-white/30 transition-colors">
                <MessageCircle className="h-5 w-5 text-white" />
              </a>
              <a href="https://x.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center hover:bg-white/30 transition-colors">
                <svg className="h-5 w-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Explore Section */}
      <section className="py-8 px-4">
        <div className="container mx-auto max-w-5xl">
          <h2 className="text-xl font-semibold mb-4">Explore Snolimons</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {exploreLinks.map((link) => (
              <Link
                key={link.label}
                to={link.href}
                className="flex flex-col items-center gap-2 p-4 bg-card border border-border rounded-lg card-hover"
              >
                <link.icon className={`h-6 w-6 ${link.color}`} />
                <span className="text-sm font-medium text-center">{link.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-4 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="stat-card">
              <div className="flex items-center justify-between">
                <div>
                  <div className="stat-label">Players</div>
                  <div className="stat-value">{siteStats.players}</div>
                  <div className="text-xs text-muted-foreground">Players in our database</div>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Users className="h-5 w-5 text-primary" />
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center justify-between">
                <div>
                  <div className="stat-label">Accumulated RAP</div>
                  <div className="stat-value">{formatNumber(siteStats.accumulatedRap)}</div>
                  <div className="text-xs text-muted-foreground">Combined player value</div>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-primary" />
                </div>
              </div>
            </div>
            <div className="stat-card">
              <div className="flex items-center justify-between">
                <div>
                  <div className="stat-label">Total Limiteds</div>
                  <div className="stat-value">{formatNumber(siteStats.totalLimiteds)}</div>
                  <div className="text-xs text-muted-foreground">Limited items indexed</div>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Package className="h-5 w-5 text-primary" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Recently Updated */}
      <section className="py-8 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Recently Updated
              </h2>
              <p className="text-sm text-muted-foreground">Latest item value changes</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3">
            {recentlyUpdated.map((item) => (
              <ItemCard key={item.id} item={item} showRarity={false} />
            ))}
          </div>
        </div>
      </section>

      {/* Top Traders */}
      <section className="py-8 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                Top Traders
              </h2>
              <p className="text-sm text-muted-foreground">Highest value inventories</p>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/leaderboard">
                View All
                <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
          <div className="space-y-2">
            {topTraders.map((player, index) => (
              <PlayerCard 
                key={player.id} 
                player={player} 
                rank={index + 1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Trade Ads Preview */}
      <section className="py-8 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Trade Ads
              </h2>
              <p className="text-sm text-muted-foreground">Latest trade offers</p>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/trades">
                View All
                <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
          <div className="text-center py-8 text-muted-foreground">
            Trade ads will appear here
          </div>
        </div>
      </section>
    </div>
  );
}
