import { useState } from 'react';
import { 
  Calculator, 
  Plus, 
  RotateCcw, 
  Redo, 
  Trash2,
  Search
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { items, formatNumber, getItemById } from '@/data/mockData';

interface CalculatorSlot {
  itemId: number | null;
  quantity: number;
}

export function CalculatorPage() {
  const [offerSlots, setOfferSlots] = useState<CalculatorSlot[]>([
    { itemId: null, quantity: 1 },
    { itemId: null, quantity: 1 },
    { itemId: null, quantity: 1 },
    { itemId: null, quantity: 1 },
  ]);
  
  const [requestSlots, setRequestSlots] = useState<CalculatorSlot[]>([
    { itemId: null, quantity: 1 },
    { itemId: null, quantity: 1 },
    { itemId: null, quantity: 1 },
    { itemId: null, quantity: 1 },
  ]);

  const [offerCash, setOfferCash] = useState(0);
  const [requestCash, setRequestCash] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('value-high');
  const [addingTo, setAddingTo] = useState<'offer' | 'request'>('offer');
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);

  const filteredItems = items
    .filter(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'value-high') return b.value - a.value;
      if (sortBy === 'value-low') return a.value - b.value;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return 0;
    });

  const calculateTotals = (slots: CalculatorSlot[], cash: number) => {
    let totalValue = cash;
    let totalRap = 0;
    slots.forEach(slot => {
      if (slot.itemId) {
        const item = getItemById(slot.itemId);
        if (item) {
          totalValue += item.value * slot.quantity;
          totalRap += item.rap * slot.quantity;
        }
      }
    });
    return { totalValue, totalRap };
  };

  const offerTotals = calculateTotals(offerSlots, offerCash);
  const requestTotals = calculateTotals(requestSlots, requestCash);

  const addItemToSlot = (itemId: number) => {
    if (selectedSlot === null) return;
    
    if (addingTo === 'offer') {
      const newSlots = [...offerSlots];
      newSlots[selectedSlot] = { itemId, quantity: 1 };
      setOfferSlots(newSlots);
    } else {
      const newSlots = [...requestSlots];
      newSlots[selectedSlot] = { itemId, quantity: 1 };
      setRequestSlots(newSlots);
    }
    setSelectedSlot(null);
  };

  const removeItemFromSlot = (side: 'offer' | 'request', index: number) => {
    if (side === 'offer') {
      const newSlots = [...offerSlots];
      newSlots[index] = { itemId: null, quantity: 1 };
      setOfferSlots(newSlots);
    } else {
      const newSlots = [...requestSlots];
      newSlots[index] = { itemId: null, quantity: 1 };
      setRequestSlots(newSlots);
    }
  };

  const clearAll = () => {
    setOfferSlots(offerSlots.map(() => ({ itemId: null, quantity: 1 })));
    setRequestSlots(requestSlots.map(() => ({ itemId: null, quantity: 1 })));
    setOfferCash(0);
    setRequestCash(0);
  };

  const getTradeStatus = () => {
    const diff = offerTotals.totalValue - requestTotals.totalValue;
    if (Math.abs(diff) < 100) return { text: 'Fair Trade', color: 'text-yellow-400', subtext: 'Equal value trade' };
    if (diff > 0) return { text: 'Overpay', color: 'text-red-400', subtext: 'You are overpaying' };
    return { text: 'Win', color: 'text-green-400', subtext: 'You are winning' };
  };

  const tradeStatus = getTradeStatus();

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold flex items-center justify-center gap-2">
            <Calculator className="h-6 w-6 text-primary" />
            Trade Calculator
          </h1>
          <p className="text-muted-foreground">Add items to each side to compare values.</p>
        </div>

        {/* Calculator */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Offer Side */}
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">Offer</h2>
              <span className="text-sm text-muted-foreground">
                {offerSlots.filter(s => s.itemId).length}/4
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-2 mb-4">
              {offerSlots.map((slot, index) => (
                <div
                  key={index}
                  className={`aspect-square border-2 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-colors ${
                    selectedSlot === index && addingTo === 'offer'
                      ? 'border-primary bg-primary/10'
                      : slot.itemId
                      ? 'border-primary bg-primary/5'
                      : 'border-dashed border-muted hover:border-primary/50'
                  }`}
                  onClick={() => {
                    setAddingTo('offer');
                    setSelectedSlot(index);
                  }}
                >
                  {slot.itemId ? (
                    <>
                      {(() => {
                        const item = getItemById(slot.itemId);
                        return item ? (
                          <>
                            <img 
                              src={item.image} 
                              alt={item.name}
                              className="w-12 h-12 object-contain"
                            />
                            <span className="text-xs text-center line-clamp-1 mt-1 px-1">{item.name}</span>
                            <button
                              className="text-xs text-red-400 hover:text-red-300 mt-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                removeItemFromSlot('offer', index);
                              }}
                            >
                              Remove
                            </button>
                          </>
                        ) : null;
                      })()}
                    </>
                  ) : (
                    <>
                      <Plus className="h-6 w-6 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground mt-1">Add Item</span>
                    </>
                  )}
                </div>
              ))}
            </div>

            <Button 
              variant="outline" 
              className="w-full mb-3"
              onClick={() => {
                if (offerSlots.length < 4) {
                  setOfferSlots([...offerSlots, { itemId: null, quantity: 1 }]);
                }
              }}
              disabled={offerSlots.length >= 4}
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Slot
            </Button>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm text-green-400 font-medium">R$</span>
              <Input
                type="number"
                value={offerCash}
                onChange={(e) => setOfferCash(Number(e.target.value))}
                className="h-8"
                placeholder="0"
              />
            </div>

            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Value:</span>
                <span className="text-primary font-bold">{formatNumber(offerTotals.totalValue)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">RAP:</span>
                <span className="text-green-400">{formatNumber(offerTotals.totalRap)}</span>
              </div>
            </div>
          </div>

          {/* Request Side */}
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">Request</h2>
              <span className="text-sm text-muted-foreground">
                {requestSlots.filter(s => s.itemId).length}/4
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-2 mb-4">
              {requestSlots.map((slot, index) => (
                <div
                  key={index}
                  className={`aspect-square border-2 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-colors ${
                    selectedSlot === index && addingTo === 'request'
                      ? 'border-primary bg-primary/10'
                      : slot.itemId
                      ? 'border-primary bg-primary/5'
                      : 'border-dashed border-muted hover:border-primary/50'
                  }`}
                  onClick={() => {
                    setAddingTo('request');
                    setSelectedSlot(index);
                  }}
                >
                  {slot.itemId ? (
                    <>
                      {(() => {
                        const item = getItemById(slot.itemId);
                        return item ? (
                          <>
                            <img 
                              src={item.image} 
                              alt={item.name}
                              className="w-12 h-12 object-contain"
                            />
                            <span className="text-xs text-center line-clamp-1 mt-1 px-1">{item.name}</span>
                            <button
                              className="text-xs text-red-400 hover:text-red-300 mt-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                removeItemFromSlot('request', index);
                              }}
                            >
                              Remove
                            </button>
                          </>
                        ) : null;
                      })()}
                    </>
                  ) : (
                    <>
                      <Plus className="h-6 w-6 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground mt-1">Add Item</span>
                    </>
                  )}
                </div>
              ))}
            </div>

            <Button 
              variant="outline" 
              className="w-full mb-3"
              onClick={() => {
                if (requestSlots.length < 4) {
                  setRequestSlots([...requestSlots, { itemId: null, quantity: 1 }]);
                }
              }}
              disabled={requestSlots.length >= 4}
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Slot
            </Button>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm text-green-400 font-medium">R$</span>
              <Input
                type="number"
                value={requestCash}
                onChange={(e) => setRequestCash(Number(e.target.value))}
                className="h-8"
                placeholder="0"
              />
            </div>

            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Value:</span>
                <span className="text-primary font-bold">{formatNumber(requestTotals.totalValue)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">RAP:</span>
                <span className="text-green-400">{formatNumber(requestTotals.totalRap)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Trade Status */}
        <div className="bg-card border border-border rounded-lg p-4 mb-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center">
              <div className="text-sm text-muted-foreground">Your Offer:</div>
              <div className="text-xl font-bold text-primary">{formatNumber(offerTotals.totalValue)}</div>
            </div>
            <div className="text-center">
              <div className={`text-lg font-bold ${tradeStatus.color}`}>{tradeStatus.text}</div>
              <div className="text-sm text-muted-foreground">{tradeStatus.subtext}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-muted-foreground">Their Offer:</div>
              <div className="text-xl font-bold text-primary">{formatNumber(requestTotals.totalValue)}</div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-center gap-2 mb-6">
          <Button variant="outline" size="sm">
            <RotateCcw className="h-4 w-4 mr-1" />
            Undo
          </Button>
          <Button variant="outline" size="sm">
            <Redo className="h-4 w-4 mr-1" />
            Redo
          </Button>
          <Button variant="destructive" size="sm" onClick={clearAll}>
            <Trash2 className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>

        {/* Item Selector */}
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex flex-col md:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="value-high">Value: High to Low</SelectItem>
                <SelectItem value="value-low">Value: Low to High</SelectItem>
                <SelectItem value="name">Name</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Adding to:</span>
              <Button
                variant={addingTo === 'offer' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setAddingTo('offer')}
              >
                Offer
              </Button>
              <Button
                variant={addingTo === 'request' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setAddingTo('request')}
              >
                Request
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2 max-h-64 overflow-y-auto">
            {filteredItems.map((item) => (
              <button
                key={item.id}
                className="p-2 bg-muted/50 rounded-lg hover:bg-muted transition-colors text-left"
                onClick={() => addItemToSlot(item.id)}
              >
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-full aspect-square object-contain mb-1"
                />
                <div className="text-xs font-medium line-clamp-1">{item.name}</div>
                <div className="text-xs text-primary">{formatNumber(item.value)}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
