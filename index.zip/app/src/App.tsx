import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { GlobalChat } from '@/components/GlobalChat';
import { Home } from '@/pages/Home';
import { PlayerPage } from '@/pages/PlayerPage';
import { ItemPage } from '@/pages/ItemPage';
import { LimitedsPage } from '@/pages/LimitedsPage';
import { CalculatorPage } from '@/pages/CalculatorPage';
import { TradesPage } from '@/pages/TradesPage';
import { ValueChangesPage } from '@/pages/ValueChangesPage';
import { LeaderboardPage } from '@/pages/LeaderboardPage';
import { LoginPage } from '@/pages/LoginPage';
import { GiveawaysPage } from '@/pages/GiveawaysPage';
import { NotFound } from '@/pages/NotFound';
import type { Theme } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

function App() {
  const [theme, setTheme] = useState<Theme>('kolimons');
  const [showThemeDialog, setShowThemeDialog] = useState(false);

  useEffect(() => {
    // Check if user has already chosen a theme
    const savedTheme = localStorage.getItem('snolimons-theme') as Theme;
    if (savedTheme) {
      setTheme(savedTheme);
    } else {
      setShowThemeDialog(true);
    }
  }, []);

  const handleThemeChange = (newTheme: Theme) => {
    setTheme(newTheme);
    localStorage.setItem('snolimons-theme', newTheme);
    setShowThemeDialog(false);
  };

  return (
    <BrowserRouter>
      <div className={`min-h-screen bg-background text-foreground ${theme === 'rolimons' ? 'theme-rolimons' : 'theme-kolimons'}`}>
        <Navbar theme={theme} onThemeChange={handleThemeChange} />
        
        <main className="pb-20">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/player/:id" element={<PlayerPage />} />
            <Route path="/item/:id" element={<ItemPage />} />
            <Route path="/limiteds" element={<LimitedsPage />} />
            <Route path="/calculator" element={<CalculatorPage />} />
            <Route path="/trades" element={<TradesPage />} />
            <Route path="/value-changes" element={<ValueChangesPage />} />
            <Route path="/leaderboard" element={<LeaderboardPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/giveaways" element={<GiveawaysPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>

        <GlobalChat />

        {/* Theme Selection Dialog */}
        <Dialog open={showThemeDialog} onOpenChange={setShowThemeDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-center">Choose Your Theme</DialogTitle>
              <DialogDescription className="text-center">
                Would you like to use the Rolimons theme? It replicates the classic rolimons.com look and feel. 
                You can always switch later in the navbar.
              </DialogDescription>
            </DialogHeader>
            <div className="flex gap-3 mt-4">
              <Button 
                className="flex-1"
                onClick={() => handleThemeChange('rolimons')}
              >
                Rolimons Theme
              </Button>
              <Button 
                variant="outline"
                className="flex-1"
                onClick={() => handleThemeChange('kolimons')}
              >
                Snolimons Theme
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </BrowserRouter>
  );
}

export default App;
