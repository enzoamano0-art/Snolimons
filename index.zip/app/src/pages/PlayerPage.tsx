import { useParams, Link } from 'react-router-dom';
import { 
  TrendingUp, 
  Package, 
  Users, 
  ExternalLink,
  Grid3X3,
  Search,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { getPlayerById, getPlayerInventory, formatNumber } from '@/data/mockData';
import { useState } from 'react';

export function PlayerPage() {
  const { id } = useParams<{ id: string }>();
  const playerId = parseInt(id || '0');
  const player = getPlayerById(playerId);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('value-high');

  if (!player) {
    return (
      <div className="container mx-auto max-w-5xl py-12 px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Player not found</h1>
        <p className="text-muted-foreground mb-6">The player you're looking for doesn't exist.</p>
        <Button asChild>
          <Link to="/">Go Home</Link>
        </Button>
      </div>
    );
  }

  const inventory = getPlayerInventory(playerId);
  
  const filteredInventory = inventory
    .filter(item => item.name?.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'value-high') return (b.value || 0) - (a.value || 0);
      if (sortBy === 'value-low') return (a.value || 0) - (b.value || 0);
      if (sortBy === 'name') return (a.name || '').localeCompare(b.name || '');
      return 0;
    });

  const valueChange = {
    amount: 40300,
    percent: 294.7
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl space-y-6">
        {/* Profile Header */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            {/* Avatar */}
            <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center overflow-hidden">
              {player.avatar ? (
                <img src={player.avatar} alt={player.username} className="w-full h-full object-cover" />
              ) : (
                <span className="text-3xl font-bold text-muted-foreground">
                  {player.username.charAt(0).toUpperCase()}
                </span>
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-bold">{player.displayName}</h1>
                <Badge variant="secondary" className="text-xs">{player.level}</Badge>
                {player.badges?.includes('verified') && (
                  <img src="/verified-badge.png" alt="Verified" className="h-5 w-5" />
                )}
                {player.badges?.includes('admin') && (
                  <img src="/admin-badge.png" alt="Admin" className="h-5 w-5" />
                )}
                {player.badges?.includes('staff') && (
                  <img src="/staff-badge.png" alt="Staff" className="h-5 w-5" />
                )}
              </div>
              <p className="text-muted-foreground">@{player.username}</p>
              {player.bio && (
                <p className="text-sm text-muted-foreground mt-1">{player.bio}</p>
              )}
              
              <div className="flex flex-wrap gap-2 mt-3">
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  Joined {new Date(player.joinedAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </span>
              </div>

              <div className="flex flex-wrap gap-2 mt-3">
                <Button variant="outline" size="sm" asChild>
                  <a 
                    href={`https://www.pekora.zip/users/${player.id}/profile`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    View on Pekora
                  </a>
                </Button>
                <Button variant="outline" size="sm" asChild>
                  <a 
                    href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${player.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <TrendingUp className="h-4 w-4 mr-1" />
                    Trade with {player.displayName}
                  </a>
                </Button>
                <Button variant="outline" size="sm">
                  <Grid3X3 className="h-4 w-4 mr-1" />
                  View Sheet
                </Button>
              </div>
            </div>

            {/* Level Progress */}
            <div className="w-full md:w-48">
              <div className="flex items-center justify-between text-sm mb-1">
                <span>Level {player.level}</span>
                <span className="text-muted-foreground">{player.exp} / {player.maxExp} EXP</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary"
                  style={{ width: `${(player.exp / player.maxExp) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <div className="stat-label">Value</div>
                <div className="stat-value text-primary">{formatNumber(player.value)}</div>
                <div className="text-xs text-muted-foreground">Custom item values</div>
              </div>
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <div className="stat-label">RAP</div>
                <div className="stat-value">{formatNumber(player.rap)}</div>
                <div className="text-xs text-muted-foreground">Recent average price</div>
              </div>
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <div className="stat-label">Limiteds</div>
                <div className="stat-value">{player.limiteds}</div>
                <div className="text-xs text-muted-foreground">{player.uniqueItems} unique items</div>
              </div>
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Package className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="stat-card">
            <div className="flex items-center justify-between">
              <div>
                <div className="stat-label">User ID</div>
                <div className="stat-value">#{player.id}</div>
                <div className="text-xs text-muted-foreground">Pekora account ID</div>
              </div>
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
        </div>

        {/* Value History */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Value History
            </h2>
            <div className="text-green-400 text-sm font-medium">
              +{formatNumber(valueChange.amount)} ({valueChange.percent}%)
            </div>
          </div>
          <div className="h-48 flex items-end justify-between gap-2">
            {Array.from({ length: 12 }).map((_, i) => (
              <div 
                key={i}
                className="flex-1 bg-primary/20 rounded-t"
                style={{ height: `${20 + Math.random() * 60}%` }}
              />
            ))}
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-2">
            <span>Feb 4</span>
            <span>Feb 11</span>
          </div>
        </div>

        {/* Inventory */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              Inventory
              <Badge variant="secondary" className="text-xs">
                {player.limiteds} items ({player.uniqueItems} unique)
              </Badge>
            </h2>
            <div className="flex gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:w-48">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8"
                />
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="value-high">Value: High to Low</SelectItem>
                  <SelectItem value="value-low">Value: Low to High</SelectItem>
                  <SelectItem value="name">Name</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {filteredInventory.map((item, index) => (
              <Link
                key={`${item.id}-${index}`}
                to={`/item/${item.id}`}
                className="group bg-muted/50 border border-border rounded-lg p-3 card-hover"
              >
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 mb-2">
                    {item.image ? (
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <div className="w-full h-full bg-muted rounded-lg flex items-center justify-center">
                        <span className="text-2xl text-muted-foreground">?</span>
                      </div>
                    )}
                  </div>
                  <h3 className="text-sm font-medium text-center line-clamp-1 group-hover:text-primary transition-colors">
                    {item.name}
                  </h3>
                  <div className="text-primary font-bold text-sm">
                    {formatNumber(item.value || 0)}
                  </div>
                  {item.rap && item.rap > 0 && (
                    <div className="text-xs text-muted-foreground">
                      RAP: {formatNumber(item.rap)}
                    </div>
                  )}
                  {item.quantity && item.quantity > 1 && (
                    <Badge variant="secondary" className="mt-1 text-xs">
                      x{item.quantity}
                    </Badge>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
