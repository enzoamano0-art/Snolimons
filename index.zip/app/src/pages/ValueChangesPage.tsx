import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart3, 
  Search,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { valueChanges, getItemById, formatNumber } from '@/data/mockData';

export function ValueChangesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  const filteredChanges = valueChanges.filter(change =>
    change.itemName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.ceil(filteredChanges.length / itemsPerPage);
  const paginatedChanges = filteredChanges.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'numeric', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            Recent Value Changes
          </h1>
          <p className="text-muted-foreground">
            Track the latest changes in item values, demand, and trends by our value changers
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search item changes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline">
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-2 mb-6">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
          >
            First
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
            Previous
          </Button>
          <span className="text-sm text-muted-foreground">
            Page {currentPage} of {totalPages || 1}
          </span>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages || totalPages === 0}
          >
            Next
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages || totalPages === 0}
          >
            Last
          </Button>
        </div>

        {/* Changes Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {paginatedChanges.map((change, index) => {
            const item = getItemById(change.itemId);
            const isIncrease = change.newValue > change.oldValue;
            
            return (
              <Link
                key={index}
                to={`/item/${change.itemId}`}
                className="bg-card border border-border rounded-lg p-4 card-hover"
              >
                {/* Item Image */}
                <div className="w-16 h-16 mx-auto mb-3">
                  {change.itemImage || item?.image ? (
                    <img 
                      src={change.itemImage || item?.image} 
                      alt={change.itemName}
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="w-full h-full bg-muted rounded-lg flex items-center justify-center">
                      <span className="text-2xl text-muted-foreground">?</span>
                    </div>
                  )}
                </div>

                {/* Item Name */}
                <h3 className="text-sm font-medium text-center line-clamp-1 mb-2">
                  {change.itemName}
                </h3>

                {/* Change Badge */}
                <div className="flex justify-center mb-2">
                  <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded">
                    Value Changed
                  </span>
                </div>

                {/* Values */}
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Old</span>
                    <span>{formatNumber(change.oldValue)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">New</span>
                    <span className={`flex items-center gap-1 ${isIncrease ? 'text-green-400' : 'text-red-400'}`}>
                      {isIncrease ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {formatNumber(change.newValue)}
                    </span>
                  </div>
                </div>

                {/* Time */}
                <div className="mt-3 pt-3 border-t border-border text-xs text-muted-foreground">
                  <div className="flex items-center gap-1 text-primary">
                    <Clock className="h-3 w-3" />
                    {getTimeAgo(change.changedAt)}
                  </div>
                  <div>{formatDate(change.changedAt)}</div>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Empty State */}
        {paginatedChanges.length === 0 && (
          <div className="text-center py-12">
            <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No changes found</h3>
            <p className="text-muted-foreground">Try adjusting your search query</p>
          </div>
        )}
      </div>
    </div>
  );
}

// Clock icon component
function Clock({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
