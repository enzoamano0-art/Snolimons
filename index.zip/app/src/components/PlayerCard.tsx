import { Link } from 'react-router-dom';
import type { Player } from '@/types';
import { formatNumber } from '@/data/mockData';
import { TrendingUp, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PlayerCardProps {
  player: Player;
  rank?: number;
  showTrade?: boolean;
}

export function PlayerCard({ player, rank, showTrade = true }: PlayerCardProps) {
  return (
    <div className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg card-hover">
      {/* Rank */}
      {rank && (
        <div className={`flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-lg font-bold ${
          rank === 1 ? 'bg-yellow-500/20 text-yellow-500' :
          rank === 2 ? 'bg-gray-400/20 text-gray-400' :
          rank === 3 ? 'bg-orange-600/20 text-orange-600' :
          'bg-muted text-muted-foreground'
        }`}>
          {rank}
        </div>
      )}

      {/* Avatar */}
      <Link to={`/player/${player.id}`} className="flex-shrink-0">
        <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center overflow-hidden">
          {player.avatar ? (
            <img src={player.avatar} alt={player.username} className="w-full h-full object-cover" />
          ) : (
            <span className="text-lg font-bold text-muted-foreground">
              {player.username.charAt(0).toUpperCase()}
            </span>
          )}
        </div>
      </Link>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <Link 
          to={`/player/${player.id}`}
          className="font-medium hover:text-primary transition-colors flex items-center gap-1"
        >
          {player.displayName}
          {player.badges?.includes('verified') && (
            <span className="text-blue-400 text-xs">✓</span>
          )}
          {player.badges?.includes('admin') && (
            <span className="text-green-400 text-xs">🛡️</span>
          )}
          {player.badges?.includes('staff') && (
            <span className="text-purple-400 text-xs">⚡</span>
          )}
        </Link>
        <div className="text-sm text-muted-foreground">@{player.username}</div>
      </div>

      {/* Stats */}
      <div className="text-right">
        <div className="flex items-center gap-1 text-primary font-bold">
          <TrendingUp className="h-3 w-3" />
          {formatNumber(player.value)}
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Package className="h-3 w-3" />
          {player.limiteds} items
        </div>
      </div>

      {/* Trade Button */}
      {showTrade && (
        <Button 
          variant="outline" 
          size="sm"
          className="text-xs"
          asChild
        >
          <a 
            href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${player.id}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            Trade
          </a>
        </Button>
      )}
    </div>
  );
}
