import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Gift, 
  Trophy,
  Users,
  Clock,
  ArrowRight,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface Giveaway {
  id: number;
  title: string;
  description: string;
  prize: string;
  prizeImage?: string;
  endDate: string;
  participants: number;
  winner?: string;
  status: 'active' | 'ended';
}

const giveaways: Giveaway[] = [
  {
    id: 1,
    title: 'Weekly Dominus Giveaway',
    description: 'Win a Dominus Empyreus! Participate by trading on Snolimons.',
    prize: 'Dominus Empyreus',
    endDate: '2026-02-20',
    participants: 156,
    status: 'active'
  },
  {
    id: 2,
    title: 'Valentine\'s Special',
    description: 'Share the love with a Rainbow Shaggy giveaway!',
    prize: 'Rainbow Shaggy',
    endDate: '2026-02-14',
    participants: 89,
    status: 'active'
  },
  {
    id: 3,
    title: 'Top Trader Reward',
    description: 'Monthly reward for the top trader on the leaderboard.',
    prize: 'Blackvalk',
    endDate: '2026-02-28',
    participants: 234,
    status: 'active'
  },
];

export function GiveawaysPage() {
  const [selectedGiveaway, setSelectedGiveaway] = useState<Giveaway | null>(null);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const getDaysLeft = (dateString: string) => {
    const end = new Date(dateString);
    const now = new Date();
    const diffMs = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Gift className="h-6 w-6 text-primary" />
              Giveaways
            </h1>
            <p className="text-muted-foreground">
              Participate in giveaways and win amazing items
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-1" />
            Create Giveaway
          </Button>
        </div>

        {/* Active Giveaways */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {giveaways.map((giveaway) => (
            <div 
              key={giveaway.id}
              className="bg-card border border-border rounded-lg p-4 card-hover"
            >
              <div className="flex items-start justify-between mb-3">
                <Badge variant={giveaway.status === 'active' ? 'default' : 'secondary'}>
                  {giveaway.status === 'active' ? 'Active' : 'Ended'}
                </Badge>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  {giveaway.participants}
                </div>
              </div>

              <h3 className="font-semibold text-lg mb-1">{giveaway.title}</h3>
              <p className="text-sm text-muted-foreground mb-3">{giveaway.description}</p>

              <div className="bg-muted rounded-lg p-3 mb-3">
                <div className="text-sm text-muted-foreground">Prize</div>
                <div className="font-medium text-primary">{giveaway.prize}</div>
              </div>

              <div className="flex items-center justify-between text-sm mb-3">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {getDaysLeft(giveaway.endDate)} days left
                </div>
                <div className="text-muted-foreground">
                  Ends {formatDate(giveaway.endDate)}
                </div>
              </div>

              <Button 
                className="w-full"
                onClick={() => setSelectedGiveaway(giveaway)}
                disabled={giveaway.status !== 'active'}
              >
                Enter Giveaway
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {giveaways.length === 0 && (
          <div className="text-center py-12">
            <Gift className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No active giveaways</h3>
            <p className="text-muted-foreground mb-4">Check back later for new giveaways</p>
            <Button asChild>
              <Link to="/">Go Home</Link>
            </Button>
          </div>
        )}

        {/* Past Winners */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
            <Trophy className="h-5 w-5 text-primary" />
            Past Winners
          </h2>
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="text-center py-8 text-muted-foreground">
              <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No past giveaways yet</p>
            </div>
          </div>
        </div>
      </div>

      {/* Enter Giveaway Dialog */}
      <Dialog open={!!selectedGiveaway} onOpenChange={() => setSelectedGiveaway(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedGiveaway?.title}</DialogTitle>
            <DialogDescription>
              {selectedGiveaway?.description}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted rounded-lg p-4">
              <div className="text-sm text-muted-foreground">Prize</div>
              <div className="text-xl font-bold text-primary">{selectedGiveaway?.prize}</div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Users className="h-4 w-4" />
                {selectedGiveaway?.participants} participants
              </div>
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="h-4 w-4" />
                {selectedGiveaway && getDaysLeft(selectedGiveaway.endDate)} days left
              </div>
            </div>
            <Button className="w-full">
              Enter Giveaway
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              You must be logged in to enter giveaways
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
