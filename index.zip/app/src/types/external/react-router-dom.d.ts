declare module 'react-router-dom' {
  import * as React from 'react';

  export interface BrowserRouterProps {
    basename?: string;
    children?: React.ReactNode;
  }
  export class BrowserRouter extends React.Component<BrowserRouterProps> {}

  export interface RoutesProps {
    children?: React.ReactNode;
    location?: string;
  }
  export class Routes extends React.Component<RoutesProps> {}

  export interface RouteProps {
    path?: string;
    element?: React.ReactNode;
    index?: boolean;
  }
  export class Route extends React.Component<RouteProps> {}

  export interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
    to: string;
    replace?: boolean;
    state?: any;
  }
  export const Link: React.FC<LinkProps>;

  export interface NavLinkProps extends LinkProps {
    className?: string | ((props: { isActive: boolean }) => string);
    end?: boolean;
  }
  export const NavLink: React.FC<NavLinkProps>;

  export function useParams<T extends Record<string, string>>(): T;
  export function useLocation(): { pathname: string; search: string; hash: string; state: any };
  export function useNavigate(): (to: string, options?: { replace?: boolean; state?: any }) => void;
}
