import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  Trophy, 
  TrendingUp,
  Package,
  Crown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { players, formatNumber } from '@/data/mockData';

export function LeaderboardPage() {
  const sortedPlayers = useMemo(() => {
    return [...players].sort((a, b) => b.value - a.value);
  }, []);

  const top3 = sortedPlayers.slice(0, 3);
  const rest = sortedPlayers.slice(3);

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-b from-yellow-500/20 to-transparent border-yellow-500/50';
      case 2:
        return 'bg-gradient-to-b from-gray-400/20 to-transparent border-gray-400/50';
      case 3:
        return 'bg-gradient-to-b from-orange-600/20 to-transparent border-orange-600/50';
      default:
        return 'bg-card border-border';
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-4">
            <Trophy className="h-5 w-5" />
            <span className="font-medium">Top Traders</span>
          </div>
          <h1 className="text-3xl font-bold mb-2">Leaderboard</h1>
          <p className="text-muted-foreground">
            The richest traders on Pekora ranked by total Value
          </p>
        </div>

        {/* Top 3 Podium */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {/* 2nd Place */}
          {top3[1] && (
            <div className={`${getRankStyle(2)} border rounded-lg p-6 text-center order-2 md:order-1`}>
              <div className="text-4xl font-bold text-gray-400 mb-2">#2</div>
              <Link to={`/player/${top3[1].id}`}>
                <div className="w-20 h-20 mx-auto mb-3 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                  {top3[1].avatar ? (
                    <img src={top3[1].avatar} alt={top3[1].username} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-2xl font-bold text-muted-foreground">
                      {top3[1].username.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>
              </Link>
              <Link 
                to={`/player/${top3[1].id}`}
                className="font-semibold text-lg hover:text-primary transition-colors flex items-center justify-center gap-1"
              >
                {top3[1].displayName}
                {top3[1].badges?.includes('verified') && <span className="text-blue-400 text-sm">✓</span>}
                {top3[1].badges?.includes('admin') && <span className="text-green-400 text-sm">🛡️</span>}
                {top3[1].badges?.includes('staff') && <span className="text-purple-400 text-sm">⚡</span>}
              </Link>
              <p className="text-muted-foreground text-sm">@{top3[1].username}</p>
              <div className="mt-3">
                <div className="text-primary font-bold text-xl flex items-center justify-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  {formatNumber(top3[1].value)} Value
                </div>
                <div className="text-sm text-muted-foreground flex items-center justify-center gap-1 mt-1">
                  <Package className="h-3 w-3" />
                  {top3[1].limiteds} items
                </div>
              </div>
              <Button variant="outline" size="sm" className="mt-3" asChild>
                <a 
                  href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${top3[1].id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Trade
                </a>
              </Button>
            </div>
          )}

          {/* 1st Place */}
          {top3[0] && (
            <div className={`${getRankStyle(1)} border rounded-lg p-6 text-center order-1 md:order-2 transform md:-translate-y-4`}>
              <div className="text-4xl font-bold text-yellow-500 mb-2">#1</div>
              <Link to={`/player/${top3[0].id}`}>
                <div className="w-24 h-24 mx-auto mb-3 rounded-full bg-muted flex items-center justify-center overflow-hidden ring-4 ring-yellow-500/30">
                  {top3[0].avatar ? (
                    <img src={top3[0].avatar} alt={top3[0].username} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-3xl font-bold text-muted-foreground">
                      {top3[0].username.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>
              </Link>
              <Link 
                to={`/player/${top3[0].id}`}
                className="font-semibold text-xl hover:text-primary transition-colors flex items-center justify-center gap-1"
              >
                {top3[0].displayName}
                {top3[0].badges?.includes('verified') && <span className="text-blue-400">✓</span>}
                {top3[0].badges?.includes('admin') && <span className="text-green-400">🛡️</span>}
                {top3[0].badges?.includes('staff') && <span className="text-purple-400">⚡</span>}
              </Link>
              <p className="text-muted-foreground">@{top3[0].username}</p>
              <div className="mt-3">
                <div className="text-primary font-bold text-2xl flex items-center justify-center gap-1">
                  <TrendingUp className="h-5 w-5" />
                  {formatNumber(top3[0].value)} Value
                </div>
                <div className="text-sm text-muted-foreground flex items-center justify-center gap-1 mt-1">
                  <Package className="h-3 w-3" />
                  {top3[0].limiteds} items
                </div>
              </div>
              <Button variant="outline" size="sm" className="mt-3" asChild>
                <a 
                  href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${top3[0].id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Trade
                </a>
              </Button>
            </div>
          )}

          {/* 3rd Place */}
          {top3[2] && (
            <div className={`${getRankStyle(3)} border rounded-lg p-6 text-center order-3`}>
              <div className="text-4xl font-bold text-orange-600 mb-2">#3</div>
              <Link to={`/player/${top3[2].id}`}>
                <div className="w-20 h-20 mx-auto mb-3 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                  {top3[2].avatar ? (
                    <img src={top3[2].avatar} alt={top3[2].username} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-2xl font-bold text-muted-foreground">
                      {top3[2].username.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>
              </Link>
              <Link 
                to={`/player/${top3[2].id}`}
                className="font-semibold text-lg hover:text-primary transition-colors flex items-center justify-center gap-1"
              >
                {top3[2].displayName}
                {top3[2].badges?.includes('verified') && <span className="text-blue-400 text-sm">✓</span>}
                {top3[2].badges?.includes('admin') && <span className="text-green-400 text-sm">🛡️</span>}
                {top3[2].badges?.includes('staff') && <span className="text-purple-400 text-sm">⚡</span>}
              </Link>
              <p className="text-muted-foreground text-sm">@{top3[2].username}</p>
              <div className="mt-3">
                <div className="text-primary font-bold text-xl flex items-center justify-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  {formatNumber(top3[2].value)} Value
                </div>
                <div className="text-sm text-muted-foreground flex items-center justify-center gap-1 mt-1">
                  <Package className="h-3 w-3" />
                  {top3[2].limiteds} items
                </div>
              </div>
              <Button variant="outline" size="sm" className="mt-3" asChild>
                <a 
                  href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${top3[2].id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Trade
                </a>
              </Button>
            </div>
          )}
        </div>

        {/* Rankings List */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <Trophy className="h-5 w-5 text-primary" />
            Rankings
            <span className="text-sm text-muted-foreground font-normal">
              {sortedPlayers.length} players
            </span>
          </h2>

          <div className="space-y-2">
            {rest.map((player, index) => {
              const rank = index + 4;
              return (
                <div 
                  key={player.id}
                  className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
                >
                  {/* Rank */}
                  <div className="w-8 h-8 flex items-center justify-center bg-muted rounded-lg font-bold text-muted-foreground">
                    {rank}
                  </div>

                  {/* Avatar */}
                  <Link to={`/player/${player.id}`}>
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                      {player.avatar ? (
                        <img src={player.avatar} alt={player.username} className="w-full h-full object-cover" />
                      ) : (
                        <span className="font-bold text-muted-foreground">
                          {player.username.charAt(0).toUpperCase()}
                        </span>
                      )}
                    </div>
                  </Link>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <Link 
                      to={`/player/${player.id}`}
                      className="font-medium hover:text-primary transition-colors flex items-center gap-1"
                    >
                      {player.displayName}
                      {player.badges?.includes('verified') && <span className="text-blue-400 text-xs">✓</span>}
                      {player.badges?.includes('admin') && <span className="text-green-400 text-xs">🛡️</span>}
                      {player.badges?.includes('staff') && <span className="text-purple-400 text-xs">⚡</span>}
                    </Link>
                    <div className="text-sm text-muted-foreground">@{player.username}</div>
                  </div>

                  {/* Stats */}
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-primary font-bold">
                      <TrendingUp className="h-3 w-3" />
                      {formatNumber(player.value)}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Package className="h-3 w-3" />
                      {player.limiteds} items
                    </div>
                  </div>

                  {/* Trade Button */}
                  <Button variant="outline" size="sm" asChild>
                    <a 
                      href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${player.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Trade
                    </a>
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
