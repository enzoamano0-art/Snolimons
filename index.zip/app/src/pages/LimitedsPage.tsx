import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Package,
  TrendingUp,
  BarChart3
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { items, formatNumber } from '@/data/mockData';

export function LimitedsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('value-high');

  const filteredItems = useMemo(() => {
    let result = items.filter(item => 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.id.toString().includes(searchQuery)
    );

    switch (sortBy) {
      case 'value-high':
        result = result.sort((a, b) => b.value - a.value);
        break;
      case 'value-low':
        result = result.sort((a, b) => a.value - b.value);
        break;
      case 'rap-high':
        result = result.sort((a, b) => b.rap - a.rap);
        break;
      case 'name':
        result = result.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    return result;
  }, [searchQuery, sortBy]);

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Package className="h-6 w-6 text-primary" />
            Limiteds
          </h1>
          <p className="text-muted-foreground">Browse all valued limiteds on Snolimons</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search by name or asset ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="value-high">Highest Value</SelectItem>
              <SelectItem value="value-low">Lowest Value</SelectItem>
              <SelectItem value="rap-high">Highest RAP</SelectItem>
              <SelectItem value="name">Name</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Results Count */}
        <div className="flex items-center gap-2 mb-4">
          <Package className="h-4 w-4 text-primary" />
          <span className="font-medium">All Limiteds</span>
          <span className="text-muted-foreground">{filteredItems.length} limiteds</span>
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {filteredItems.map((item) => (
            <Link
              key={item.id}
              to={`/item/${item.id}`}
              className="group bg-card border border-border rounded-lg p-3 card-hover"
            >
              <div className="flex flex-col items-center">
                {/* Item Image */}
                <div className="w-16 h-16 mb-2">
                  {item.image ? (
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"%3E%3Crect width="64" height="64" fill="%23333" rx="8"/%3E%3Ctext x="32" y="36" text-anchor="middle" fill="%23666" font-size="24"%3E?%3C/text%3E%3C/svg%3E';
                      }}
                    />
                  ) : (
                    <div className="w-full h-full bg-muted rounded-lg flex items-center justify-center">
                      <span className="text-2xl text-muted-foreground">?</span>
                    </div>
                  )}
                </div>

                {/* Item Name */}
                <h3 className="text-sm font-medium text-center line-clamp-1 mb-1 group-hover:text-primary transition-colors">
                  {item.name}
                </h3>

                {/* Value */}
                <div className="flex items-center gap-1 text-primary font-bold">
                  <TrendingUp className="h-3 w-3" />
                  {formatNumber(item.value)}
                </div>

                {/* RAP */}
                {item.rap > 0 && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <BarChart3 className="h-3 w-3" />
                    RAP: {formatNumber(item.rap)}
                  </div>
                )}

                {/* Demand & Copies */}
                <div className="flex items-center gap-2 mt-1 text-xs">
                  <span className={`capitalize ${
                    item.demand === 'high' ? 'text-green-400' :
                    item.demand === 'normal' ? 'text-yellow-400' :
                    'text-red-400'
                  }`}>
                    {item.demand}
                  </span>
                  {item.copies && (
                    <span className="text-muted-foreground">
                      {item.copies} copies
                    </span>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No items found</h3>
            <p className="text-muted-foreground">Try adjusting your search query</p>
          </div>
        )}
      </div>
    </div>
  );
}
