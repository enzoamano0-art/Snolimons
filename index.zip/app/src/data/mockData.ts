import type { Item, Player, TradeAd, ValueChange, ChatMessage } from '@/types';

// Items from Kolimons
export const items: Item[] = [
  { id: 37738, name: 'Dominus Empyreus', value: 125000, rap: 12100, demand: 'high', copies: 10, image: 'https://i.imgur.com/8QmQhKj.png', rarity: 'mythic', updatedAt: '2026-02-05' },
  { id: 36141, name: 'Dominus Infernus', value: 75000, rap: 9700, demand: 'high', copies: 10, image: 'https://i.imgur.com/3QZQZKL.png', rarity: 'mythic', updatedAt: '2026-02-08' },
  { id: 56781, name: 'Domino Crown', value: 75000, rap: 0, demand: 'low', copies: 10, image: 'https://i.imgur.com/5X5X5X5.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 47240, name: 'Duke of the Federation', value: 65000, rap: 19400, demand: 'low', copies: 12, image: 'https://i.imgur.com/6Y6Y6Y6.png', rarity: 'legendary', updatedAt: '2026-02-07' },
  { id: 32155, name: 'Bling $$ Necklace', value: 55000, rap: 6300, demand: 'high', copies: 20, image: 'https://i.imgur.com/7Z7Z7Z7.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 39190, name: 'Dominus Astra', value: 55000, rap: 15000, demand: 'high', copies: 14, image: 'https://i.imgur.com/9A9A9A9.png', rarity: 'mythic', updatedAt: '2026-02-05' },
  { id: 77953, name: 'Lord of the Federation', value: 55000, rap: 0, demand: 'low', copies: 10, image: 'https://i.imgur.com/1B1B1B1.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 53061, name: 'Eccentric Shop Teacher', value: 52700, rap: 6500, demand: 'low', copies: 13, image: 'https://i.imgur.com/2C2C2C2.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 44745, name: 'Red Sparkle Time Fedora', value: 47500, rap: 25000, demand: 'high', copies: 15, image: 'https://i.imgur.com/3D3D3D3.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 378194, name: 'Archduke of the Federation', value: 46000, rap: 0, demand: 'low', copies: 17, image: 'https://i.imgur.com/4E4E4E4.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 31413, name: 'Dominus Frigidus', value: 37500, rap: 7000, demand: 'normal', copies: 25, image: 'https://i.imgur.com/5F5F5F5.png', rarity: 'mythic', updatedAt: '2026-02-05' },
  { id: 41910, name: 'Midnight Blue Sparkle Time Fedora', value: 35500, rap: 11800, demand: 'normal', copies: 30, image: 'https://i.imgur.com/6G6G6G6.png', rarity: 'legendary', updatedAt: '2026-02-11' },
  { id: 373589, name: 'Red Tango', value: 29000, rap: 11300, demand: 'low', copies: 30, image: 'https://i.imgur.com/7H7H7H7.png', rarity: 'rare', updatedAt: '2026-02-04' },
  { id: 16588, name: 'Rainbow Shaggy', value: 26500, rap: 3200, demand: 'high', copies: 30, image: 'https://i.imgur.com/8I8I8I8.png', rarity: 'legendary', updatedAt: '2026-02-11' },
  { id: 46118, name: 'Green Sparkle Time Fedora', value: 25000, rap: 4000, demand: 'high', copies: 21, image: 'https://i.imgur.com/9J9J9J9.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 46615, name: 'Blackvalk', value: 22500, rap: 3000, demand: 'normal', copies: 30, image: 'https://i.imgur.com/0K0K0K0.png', rarity: 'legendary', updatedAt: '2026-02-12' },
  { id: 32732, name: 'Purple Sparkle Time Fedora', value: 22500, rap: 3900, demand: 'normal', copies: 40, image: 'https://i.imgur.com/1L1L1L1.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 16821, name: 'Eerie Pumpkin Head', value: 22000, rap: 4600, demand: 'low', copies: 35, image: 'https://i.imgur.com/2M2M2M2.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 15753, name: 'Memento Mori', value: 8500, rap: 1100, demand: 'normal', copies: 50, image: 'https://i.imgur.com/3N3N3N3.png', rarity: 'rare', updatedAt: '2026-02-11' },
  { id: 426502, name: 'Violet Fang', value: 478, rap: 150, demand: 'normal', copies: 100, image: 'https://i.imgur.com/4O4O4O4.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 426420, name: 'Sad Clown', value: 1300, rap: 400, demand: 'low', copies: 80, image: 'https://i.imgur.com/5P5P5P5.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 425070, name: 'Musica Frigidus Dominator', value: 408, rap: 120, demand: 'normal', copies: 100, image: 'https://i.imgur.com/6Q6Q6Q6.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 420678, name: 'Bag O\' Noobs', value: 54, rap: 20, demand: 'low', copies: 200, image: 'https://i.imgur.com/7R7R7R7.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 366982, name: 'Firebrand', value: 4500, rap: 4200, demand: 'normal', copies: 50, image: 'https://i.imgur.com/8S8S8S8.png', rarity: 'rare', updatedAt: '2026-02-04' },
  { id: 36461, name: 'Valkyrie Helm', value: 4000, rap: 3500, demand: 'high', copies: 60, image: 'https://i.imgur.com/9T9T9T9.png', rarity: 'legendary', updatedAt: '2026-02-05' },
  { id: 326567, name: 'Noob Assist: Donut Dash', value: 0, rap: 2000, demand: 'normal', copies: 100, image: 'https://i.imgur.com/0U0U0U0.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 43898, name: 'Red Void Star', value: 3500, rap: 3300, demand: 'normal', copies: 55, image: 'https://i.imgur.com/1V1V1V1.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 328739, name: 'Yellow Glowing Eyes', value: 0, rap: 3400, demand: 'normal', copies: 70, image: 'https://i.imgur.com/2W2W2W2.png', rarity: 'rare', updatedAt: '2026-02-05' },
  { id: 47854, name: 'Adurite King of the Night', value: 0, rap: 3000, demand: 'normal', copies: 65, image: 'https://i.imgur.com/3X3X3X3.png', rarity: 'rare', updatedAt: '2026-02-05' },
];

// Players
export const players: Player[] = [
  {
    id: 12,
    username: 'BadDecisions',
    displayName: 'BadDecisions',
    level: 50,
    exp: 5000,
    maxExp: 10000,
    value: 5750000,
    rap: 5200000,
    limiteds: 8664,
    uniqueItems: 4500,
    joinedAt: '2024-01-15',
    bio: 'Top trader on Snolimons',
    inventory: [{ itemId: 37738, quantity: 1 }, { itemId: 36141, quantity: 2 }],
    badges: ['admin', 'verified']
  },
  {
    id: 712,
    username: 'margiela',
    displayName: 'margiela',
    level: 45,
    exp: 7500,
    maxExp: 10000,
    value: 1350000,
    rap: 1200000,
    limiteds: 399,
    uniqueItems: 350,
    joinedAt: '2024-03-20',
    bio: 'Verified trader',
    inventory: [{ itemId: 39190, quantity: 1 }],
    badges: ['staff', 'verified']
  },
  {
    id: 4834,
    username: 'bloodyveil',
    displayName: 'bloodyveil',
    level: 42,
    exp: 6000,
    maxExp: 10000,
    value: 1300000,
    rap: 1150000,
    limiteds: 164,
    uniqueItems: 150,
    joinedAt: '2024-02-10',
    bio: 'Admin on Snolimons',
    inventory: [{ itemId: 56781, quantity: 1 }],
    badges: ['admin', 'verified']
  },
  {
    id: 16830,
    username: 'emotional',
    displayName: 'emotional',
    level: 38,
    exp: 4500,
    maxExp: 10000,
    value: 874100,
    rap: 800000,
    limiteds: 146,
    uniqueItems: 120,
    joinedAt: '2024-04-05',
    bio: '',
    inventory: [{ itemId: 32155, quantity: 1 }],
    badges: ['admin', 'verified']
  },
  {
    id: 13822,
    username: 'SuperMario',
    displayName: 'SuperMario',
    level: 35,
    exp: 3000,
    maxExp: 10000,
    value: 832800,
    rap: 750000,
    limiteds: 135,
    uniqueItems: 110,
    joinedAt: '2024-05-12',
    bio: '',
    inventory: [{ itemId: 47240, quantity: 1 }],
    badges: ['staff', 'verified']
  },
  {
    id: 20170,
    username: 'Snownxxxd',
    displayName: 'Snownxxxd',
    level: 1,
    exp: 5,
    maxExp: 100,
    value: 54000,
    rap: 52800,
    limiteds: 129,
    uniqueItems: 86,
    joinedAt: '2025-08-11',
    bio: 'Korone imWq',
    inventory: [
      { itemId: 366982, quantity: 1 },
      { itemId: 36461, quantity: 1 },
      { itemId: 326567, quantity: 2 },
      { itemId: 43898, quantity: 1 },
      { itemId: 328739, quantity: 1 },
      { itemId: 47854, quantity: 1 },
    ],
    badges: []
  },
  {
    id: 5534,
    username: 'Lizzy',
    displayName: 'Lizzy',
    level: 25,
    exp: 2000,
    maxExp: 10000,
    value: 450000,
    rap: 400000,
    limiteds: 85,
    uniqueItems: 70,
    joinedAt: '2024-06-01',
    bio: 'Trading Dominus Aureus',
    inventory: [{ itemId: 16588, quantity: 1 }],
    badges: []
  },
  {
    id: 47429,
    username: 'byx',
    displayName: 'byx',
    level: 20,
    exp: 1500,
    maxExp: 10000,
    value: 320000,
    rap: 280000,
    limiteds: 65,
    uniqueItems: 55,
    joinedAt: '2024-07-15',
    bio: '',
    inventory: [{ itemId: 46615, quantity: 1 }],
    badges: []
  },
  {
    id: 22119,
    username: 'comlarp',
    displayName: 'comlarp',
    level: 18,
    exp: 1200,
    maxExp: 10000,
    value: 280000,
    rap: 250000,
    limiteds: 55,
    uniqueItems: 45,
    joinedAt: '2024-08-01',
    bio: '',
    inventory: [{ itemId: 32732, quantity: 1 }],
    badges: []
  },
  {
    id: 54871,
    username: 'yvck',
    displayName: 'yvck',
    level: 15,
    exp: 1000,
    maxExp: 10000,
    value: 200000,
    rap: 180000,
    limiteds: 40,
    uniqueItems: 35,
    joinedAt: '2024-09-10',
    bio: '',
    inventory: [{ itemId: 16821, quantity: 1 }],
    badges: []
  },
];

// Trade Ads
export const tradeAds: TradeAd[] = [
  {
    id: 1,
    playerId: 58186,
    playerName: 'v10w',
    createdAt: '2026-02-12T10:00:00Z',
    offering: [{ itemId: 425070, quantity: 1 }, { itemId: 97141, quantity: 1 }, { itemId: 43164, quantity: 1 }, { itemId: 420683, quantity: 1 }],
    requesting: [],
    offerValue: 0,
    offerRap: 1100,
    requestValue: 0,
    requestRap: 0,
    comments: 0
  },
  {
    id: 2,
    playerId: 5534,
    playerName: 'Lizzy',
    createdAt: '2026-02-12T09:58:00Z',
    offering: [{ itemId: 346049, quantity: 1 }, { itemId: 112799, quantity: 1 }, { itemId: 343940, quantity: 1 }, { itemId: 344979, quantity: 1 }],
    requesting: [],
    offerValue: 0,
    offerRap: 1300,
    requestValue: 0,
    requestRap: 0,
    comments: 0
  },
  {
    id: 3,
    playerId: 47429,
    playerName: 'byx',
    createdAt: '2026-02-12T09:00:00Z',
    offering: [{ itemId: 392223, quantity: 1 }, { itemId: 31731, quantity: 1 }],
    requesting: [{ itemId: 46615, quantity: 1 }],
    offerValue: 16000,
    offerRap: 20800,
    requestValue: 22500,
    requestRap: 3000,
    comments: 2
  },
];

// Value Changes
export const valueChanges: ValueChange[] = [
  { itemId: 46615, itemName: 'Blackvalk', itemImage: 'https://i.imgur.com/0K0K0K0.png', oldValue: 18500, newValue: 22500, changedAt: '2026-02-12T08:17:41Z', type: 'value' },
  { itemId: 41910, itemName: 'Midnight Blue Sparkle Time Fedora', itemImage: 'https://i.imgur.com/6G6G6G6.png', oldValue: 29000, newValue: 35500, changedAt: '2026-02-11T08:30:13Z', type: 'value' },
  { itemId: 15753, itemName: 'Memento Mori', itemImage: 'https://i.imgur.com/3N3N3N3.png', oldValue: 3800, newValue: 8500, changedAt: '2026-02-11T08:29:52Z', type: 'value' },
  { itemId: 16588, itemName: 'Rainbow Shaggy', itemImage: 'https://i.imgur.com/8I8I8I8.png', oldValue: 20500, newValue: 26500, changedAt: '2026-02-11T08:29:35Z', type: 'value' },
  { itemId: 36141, itemName: 'Dominus Infernus', itemImage: 'https://i.imgur.com/3QZQZKL.png', oldValue: 59000, newValue: 75000, changedAt: '2026-02-08T11:51:04Z', type: 'value' },
  { itemId: 47240, itemName: 'Duke of the Federation', itemImage: 'https://i.imgur.com/6Y6Y6Y6.png', oldValue: 50000, newValue: 65000, changedAt: '2026-02-07T07:16:02Z', type: 'value' },
  { itemId: 378194, itemName: 'Archduke of the Federation', itemImage: 'https://i.imgur.com/4E4E4E4.png', oldValue: 44000, newValue: 46000, changedAt: '2026-02-05T07:54:54Z', type: 'value' },
  { itemId: 366982, itemName: 'Firebrand', itemImage: 'https://i.imgur.com/8S8S8S8.png', oldValue: 0, newValue: 4500, changedAt: '2026-02-04T06:51:08Z', type: 'value' },
];

// Chat Messages
export const chatMessages: ChatMessage[] = [
  { id: 1, playerId: 47429, playerName: 'byx', message: 'for a up only', timestamp: '07:34' },
  { id: 2, playerId: 22119, playerName: 'comlarp', message: 'is anyone trading pistf', timestamp: '08:36' },
  { id: 3, playerId: 54871, playerName: 'yvck', message: 'anyone trading any valk', timestamp: '09:51' },
  { id: 4, playerId: 5534, playerName: 'Lizzy', message: 'Upgrading my low raps, will overpay for upgrades', timestamp: '10:25' },
  { id: 5, playerId: 47429, playerName: 'byx', message: 'me', timestamp: '07:34', replyTo: 'comlarp' },
];

// Stats
export const siteStats = {
  players: 394,
  accumulatedRap: 25900000,
  totalLimiteds: 36000,
};

// Get item by ID
export function getItemById(id: number): Item | undefined {
  return items.find(item => item.id === id);
}

// Get player by ID
export function getPlayerById(id: number): Player | undefined {
  return players.find(player => player.id === id);
}

// Get player inventory with item details
export function getPlayerInventory(playerId: number) {
  const player = getPlayerById(playerId);
  if (!player) return [];
  
  return player.inventory.map(invItem => {
    const item = getItemById(invItem.itemId);
    return {
      ...item,
      quantity: invItem.quantity,
      ownerSince: invItem.ownerSince
    };
  }).filter(item => item.id !== undefined);
}

// Format number with K/M suffix
export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(2) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

// Format value with commas
export function formatValue(num: number): string {
  return num.toLocaleString();
}

// Generate random verification code (5 chars)
export function generateVerificationCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let code = '';
  for (let i = 0; i < 5; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}
