import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  TrendingUp, 
  MessageSquare,
  Share2,
  Clock,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { tradeAds, getItemById, getPlayerById, formatNumber } from '@/data/mockData';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export function TradesPage() {
  const [selectedTrade, setSelectedTrade] = useState<typeof tradeAds[0] | null>(null);

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-primary" />
            Trade Ads
          </h1>
          <p className="text-muted-foreground">Browse and post trade advertisements</p>
        </div>

        {/* Trade List */}
        <div className="space-y-4">
          {tradeAds.map((trade) => {
            const player = getPlayerById(trade.playerId);
            return (
              <div 
                key={trade.id}
                className="bg-card border border-border rounded-lg p-4 card-hover"
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Link to={`/player/${trade.playerId}`}>
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                        <span className="font-bold text-muted-foreground">
                          {trade.playerName.charAt(0).toUpperCase()}
                        </span>
                      </div>
                    </Link>
                    <div>
                      <Link 
                        to={`/player/${trade.playerId}`}
                        className="font-medium hover:text-primary transition-colors"
                      >
                        {trade.playerName}
                      </Link>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <TrendingUp className="h-3 w-3" />
                          Trade
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {trade.createdAt}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>

                {/* Trade Content */}
                <div className="flex flex-col md:flex-row items-center gap-4">
                  {/* Offering */}
                  <div className="flex-1 w-full">
                    <div className="text-sm text-muted-foreground mb-2">Offering</div>
                    <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                      {trade.offering.map((offer, idx) => {
                        const item = getItemById(offer.itemId);
                        return item ? (
                          <Link
                            key={idx}
                            to={`/item/${item.id}`}
                            className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center hover:ring-2 hover:ring-primary transition-all"
                          >
                            <img 
                              src={item.image} 
                              alt={item.name}
                              className="w-10 h-10 object-contain"
                            />
                          </Link>
                        ) : (
                          <div key={idx} className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                            <span className="text-xs text-muted-foreground">?</span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="mt-2 text-sm">
                      <span className="text-muted-foreground">Value: </span>
                      <span className="text-primary font-medium">{formatNumber(trade.offerValue)}</span>
                      <span className="text-muted-foreground ml-2">RAP: </span>
                      <span className="text-green-400">{formatNumber(trade.offerRap)}</span>
                    </div>
                  </div>

                  {/* Arrow */}
                  <ArrowRight className="h-6 w-6 text-muted-foreground hidden md:block" />

                  {/* Requesting */}
                  <div className="flex-1 w-full">
                    <div className="text-sm text-muted-foreground mb-2">Requesting</div>
                    <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                      {trade.requesting.length > 0 ? trade.requesting.map((req, idx) => {
                        const item = getItemById(req.itemId);
                        return item ? (
                          <Link
                            key={idx}
                            to={`/item/${item.id}`}
                            className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center hover:ring-2 hover:ring-primary transition-all"
                          >
                            <img 
                              src={item.image} 
                              alt={item.name}
                              className="w-10 h-10 object-contain"
                            />
                          </Link>
                        ) : (
                          <div key={idx} className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
                            <span className="text-xs text-muted-foreground">?</span>
                          </div>
                        );
                      }) : (
                        <div className="text-sm text-muted-foreground">Any offers</div>
                      )}
                    </div>
                    {trade.requesting.length > 0 && (
                      <div className="mt-2 text-sm">
                        <span className="text-muted-foreground">Value: </span>
                        <span className="text-primary font-medium">{formatNumber(trade.requestValue)}</span>
                        <span className="text-muted-foreground ml-2">RAP: </span>
                        <span className="text-green-400">{formatNumber(trade.requestRap)}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setSelectedTrade(trade)}
                  >
                    <MessageSquare className="h-4 w-4 mr-1" />
                    Show Comments
                  </Button>
                  <Button size="sm" asChild>
                    <a 
                      href={`https://www.pekora.zip/Trade/TradeWindow.aspx?TradePartnerID=${trade.playerId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Trade
                    </a>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Comments Dialog */}
        <Dialog open={!!selectedTrade} onOpenChange={() => setSelectedTrade(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Comments</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="text-center text-muted-foreground py-8">
                No comments yet
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
