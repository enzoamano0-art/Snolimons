// Types for Snolimons

export interface Item {
  id: number;
  name: string;
  value: number;
  rap: number;
  demand: 'low' | 'normal' | 'high';
  copies?: number;
  image?: string;
  rarity?: 'rare' | 'legendary' | 'mythic';
  updatedAt?: string;
}

export interface Player {
  id: number;
  username: string;
  displayName: string;
  avatar?: string;
  level: number;
  exp: number;
  maxExp: number;
  value: number;
  rap: number;
  limiteds: number;
  uniqueItems: number;
  joinedAt: string;
  bio?: string;
  inventory: InventoryItem[];
  badges?: string[];
}

export interface InventoryItem {
  itemId: number;
  quantity: number;
  ownerSince?: string;
}

export interface TradeAd {
  id: number;
  playerId: number;
  playerName: string;
  playerAvatar?: string;
  createdAt: string;
  offering: TradeItem[];
  requesting: TradeItem[];
  offerValue: number;
  offerRap: number;
  requestValue: number;
  requestRap: number;
  comments?: number;
}

export interface TradeItem {
  itemId: number;
  quantity: number;
}

export interface ValueChange {
  itemId: number;
  itemName: string;
  itemImage?: string;
  oldValue: number;
  newValue: number;
  changedAt: string;
  type: 'value' | 'demand';
}

export interface ChatMessage {
  id: number;
  playerId: number;
  playerName: string;
  playerAvatar?: string;
  message: string;
  timestamp: string;
  replyTo?: string;
}

export type Theme = 'kolimons' | 'rolimons';
